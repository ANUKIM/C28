# PiratesInvasionStage-6

adding sounds and score
